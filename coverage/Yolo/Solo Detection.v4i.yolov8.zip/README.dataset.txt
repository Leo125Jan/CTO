# Solo Detection > 2024-05-18 5:08pm
https://universe.roboflow.com/drone-detection-u4baf/solo-detection

Provided by a Roboflow user
License: CC BY 4.0

