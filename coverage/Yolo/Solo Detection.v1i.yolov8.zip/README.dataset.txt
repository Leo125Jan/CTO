# Solo Detection > 2024-05-17 7:49pm
https://universe.roboflow.com/drone-detection-u4baf/solo-detection

Provided by a Roboflow user
License: CC BY 4.0

